package com.example.pjt8.socket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocketDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocketDemoApplication.class, args);
	}

}

package com.example.pjt8.socket.config;


import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

@Configuration //설정임을 나타냄
@EnableWebSocket //websocket 기능 활성화
public class WebSocketConfig implements WebSocketConfigurer { //websocket 통신을 구현하기 위한 추상클래스

	private final com.example.pjt8.socket.config.WebSocketHandler webSocketHandler;

	public WebSocketConfig(com.example.pjt8.socket.config.WebSocketHandler webSocketHandler){
		this.webSocketHandler = webSocketHandler;
	}

	@Override
	public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
		//WebSocket 요청을 처리할 핸들러 인스턴스 , WebSocket 엔드포인트 경로 ("/chat")
		//클라이언트는 "ws://host:port/chat"로 연결할 수 있음
			registry.addHandler(webSocketHandler, "/chat")
					.setAllowedOrigins("*");
	}
}

package com.example.pjt8.socket.config;

import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.io.IOException;
import java.util.concurrent.CopyOnWriteArrayList;

@Component
public class WebSocketHandler extends TextWebSocketHandler {

	// 연결된 모든 WebSocket 세션을 저장하는 리스트

	// 'CopyOnWriteArrayList'
	// 쓰기 작업이 일어날 때마다 새로운 배열을 생성하고, 기존 배열을 수정하지 않음으로써, 다른 스레드에서 읽기 작업을 안전하게 수행할 수 있다.
	// 이렇게 하면 읽기 작업은 쓰기 작업의 영향을 받지 않게 된다.
	//동시성 제어를 제공하지만, 쓰기 작업이 발생할 때마다 배열을 복사하는 비용이 있으므로, 쓰기 작업이 빈번한 환경에서는 성능이 저하될 수 있다.
	private static final CopyOnWriteArrayList<WebSocketSession> sessions = new CopyOnWriteArrayList<>();

	// 1. 새로운 WebSocket 연결이 생성될 때
	@Override
	public void afterConnectionEstablished(WebSocketSession session) throws Exception {
		sessions.add(session);
		System.out.println("New WebSocket connection: " + session.getId());
	}

	// 2. 클라이언트로부터 메시지를 받았을 때
	@Override
	protected void handleTextMessage(WebSocketSession session, TextMessage message) throws IOException {
		String payload = message.getPayload();
		System.out.println("Received message: " + payload);

		// 모든 연결된 세션에 메시지 브로드캐스트
		for (WebSocketSession webSocketSession : sessions) {
			webSocketSession.sendMessage(new TextMessage("Server received: " + payload));
		}
	}

	// 3. WebSocket 연결이 종료될 때
	@Override
	public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
		sessions.remove(session);
		System.out.println("WebSocket connection closed: " + session.getId());
	}

}

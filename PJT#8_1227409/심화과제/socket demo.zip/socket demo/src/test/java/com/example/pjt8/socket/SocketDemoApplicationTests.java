package com.example.pjt8.socket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocketDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

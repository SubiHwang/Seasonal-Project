package com.example.pjt8.socket;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.client.WebSocketClient;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class WebSocketTests {

	@LocalServerPort
	private int port;

	private String getWsUrl() {
		return String.format("ws://localhost:%d/chat", port);
	}

	private WebSocketClient client;
	private CompletableFuture<String> messageFuture;
	//CompletableFuture: 비동기 작업의 결과를 기다리는데 사용


	@BeforeEach
	void setup() {
		client = new StandardWebSocketClient();
		messageFuture = new CompletableFuture<>();
	}

	//1. 기본 연결 테스트
	@Test
	void testWebSocketConnection() throws Exception {

		//비동기 환경에서 안전하게 세션을 참조하기 위해 사용
		AtomicReference<WebSocketSession> sessionRef = new AtomicReference<>();

		// 테스트용 WebSocket 핸들러
		TextWebSocketHandler handler = new TextWebSocketHandler() {
			@Override
			public void afterConnectionEstablished(WebSocketSession session) {
				sessionRef.set(session); // 연결이 성공하면 세션 저장
			}

			@Override //메시지를 받으면 messageFuture에 저장 (비동기 결과 처리)
			protected void handleTextMessage(WebSocketSession session, TextMessage message) {
				messageFuture.complete(message.getPayload()); // 메시지 수신시 Future 완료
			}
		};

		// WebSocket 연결 생성
		//1초 안에 연결이 완료되어야 하고 연결된 세션이 null이 아닌지 확인
		client.execute(handler, getWsUrl()).get(1, TimeUnit.SECONDS);
		Assertions.assertNotNull(sessionRef.get(), "WebSocket 연결이 성공적으로 이루어져야 합니다.");

		// 저장된 세션을 통해 서버로 메시지 전송
		WebSocketSession session = sessionRef.get();
		String testMessage = "Hello, WebSocket!";
		session.sendMessage(new TextMessage(testMessage));

		// 서버로부터의 응답을 5초 동안 대기
		String response = messageFuture.get(5, TimeUnit.SECONDS);
		assertTrue(response.contains(testMessage), //응답 메시지가 보낸 메시지를 포함하는지 확인
				"서버 응답은 전송한 메시지를 포함해야 합니다.");

		// 연결 종료
		session.close();

	}

	//2. 다중 연결 테스트 (동시 2명)
	@Test
	void testMultipleConnections() throws Exception {

		//각 클라이언트가 받을 메시지를 비동기적으로 처리하기 위한 Future 객체
		//두 클라이언트의 메시지를 각각 독립적으로 받기 위해 별도로 생성
		CompletableFuture<String> client1Messages = new CompletableFuture<>();
		CompletableFuture<String> client2Messages = new CompletableFuture<>();

		// 첫 번째 클라이언트 핸들러
		TextWebSocketHandler handler1 = new TextWebSocketHandler() {
			@Override
			protected void handleTextMessage(WebSocketSession session, TextMessage message) {
				client1Messages.complete(message.getPayload());
			}
		};

		// 두 번째 클라이언트 핸들러
		TextWebSocketHandler handler2 = new TextWebSocketHandler() {
			@Override
			protected void handleTextMessage(WebSocketSession session, TextMessage message) {
				client2Messages.complete(message.getPayload());
			}
		};

		// 두 클라이언트 연결
		//두 개의 독립적인 WebSocket 연결 생성
		//각각 1초 이내 연결 완료 요구
		WebSocketSession session1 = client.execute(handler1, getWsUrl()).get(1, TimeUnit.SECONDS);
		WebSocketSession session2 = client.execute(handler2, getWsUrl()).get(1, TimeUnit.SECONDS);

		// 첫 번째 클라이언트에서 메시지 전송
		String testMessage = "Broadcast test";
		session1.sendMessage(new TextMessage(testMessage));
		//서버는 이 메시지를 모든 연결된 클라이언트에게 브로드캐스트한다.

		// 양쪽 클라이언트 모두 메시지를 받는지 확인
		//5초 이내에 응답을 받아야 함
		String response1 = client1Messages.get(5, TimeUnit.SECONDS);
		String response2 = client2Messages.get(5, TimeUnit.SECONDS);

		//받은 메시지가 보낸 테스트 메시지를 포함하는지 검증
		assertTrue(response1.contains(testMessage),
				"첫 번째 클라이언트가 메시지를 받아야 합니다.");
		assertTrue(response2.contains(testMessage),
				"두 번째 클라이언트가 메시지를 받아야 합니다.");

		// 연결 종료
		session1.close();
		session2.close();
	}

	//3. 연결 종료 테스트
	@Test
	void testConnectionClosure() throws Exception {
		AtomicReference<Boolean> connectionClosed = new AtomicReference<>(false);

		TextWebSocketHandler handler = new TextWebSocketHandler() {
			@Override
			public void afterConnectionClosed(WebSocketSession session, org.springframework.web.socket.CloseStatus status) {
				connectionClosed.set(true);
			}
		};

		// 연결 생성
		WebSocketSession session = client.execute(handler, getWsUrl()).get(1, TimeUnit.SECONDS);

		// 연결 종료
		session.close();

		// 연결이 정상적으로 종료되었는지 확인
		Thread.sleep(1000); // 연결 종료 처리를 위한 대기
		assertTrue(connectionClosed.get(), "WebSocket 연결이 정상적으로 종료되어야 합니다.");
	}

}
